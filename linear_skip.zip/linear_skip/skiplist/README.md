# 0x0E. Linear search in skip list

